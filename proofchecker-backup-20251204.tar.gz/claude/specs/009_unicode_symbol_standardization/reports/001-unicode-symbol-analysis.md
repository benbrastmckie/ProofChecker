# Unicode Symbol Standardization Research Report

## Metadata
- **Date**: 2025-12-01
- **Agent**: research-specialist
- **Topic**: Unicode symbol standardization and documentation improvements
- **Report Type**: Codebase analysis and best practices
- **Complexity**: 3

## Executive Summary

This report documents critical Unicode corruption in README.md (45+ replacement characters U+FFFD where modal/temporal logic symbols should be), identifies missing file tree box-drawing characters in Project Structure section, and provides comprehensive recommendations for creating a formal symbols glossary following Logos project patterns. The corruption affects all logical operators (□, ◇, →) in axioms and perpetuity principles, making the README unreadable for understanding TM logic specification.

## Findings

### 1. README.md Unicode Corruption Analysis

**Location**: `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/README.md`

**Critical Issues Identified**:

The README.md file contains extensive Unicode corruption with replacement characters (`ef bf bd` bytes, displaying as `�`) in place of logical operators. Hexdump analysis reveals 45+ corrupted symbols.

**Corrupted Sections** (with line numbers from Read output):

1. **Line 18 - Modal Operators**:
   - Current: `` `�` (necessity), `�` (possibility) ``
   - Should be: `` `□` (necessity), `◇` (possibility) ``

2. **Lines 23-25 - S5 Modal Axioms**:
   - Current: `MT (�� � �), M4 (�� � ���), MB (� � ���)`
   - Should be: `MT (□φ → φ), M4 (□φ → □□φ), MB (φ → □◇φ)`

3. **Line 24 - Temporal Axioms**:
   - Current: `T4 (Future � → Future Future �), TA (� → Future past �), TL (always � → Future Past �)`
   - Should be: `T4 (Future φ → Future Future φ), TA (φ → Future past φ), TL (always φ → Future Past φ)`

4. **Line 25 - Bimodal Interaction Axioms**:
   - Current: `MF (�� → �Future �), TF (�� → Future ��)`
   - Should be: `MF (□φ → □Future φ), TF (□φ → Future □φ)`

5. **Lines 28-33 - Perpetuity Principles P1-P6**:
   - Current: All principles show `�` replacement characters
   - P1: `�� → always �` should be `□φ → always φ`
   - P2: `sometimes � → ��` should be `sometimes φ → ◇φ`
   - P3: `�� → �always �` should be `□φ → □always φ`
   - P4: `�sometimes � → ��` should be `◇sometimes φ → ◇φ`
   - P5: `�sometimes � → always ��` should be `◇sometimes φ → always ◇φ`
   - P6: `sometimes �� → �always �` should be `sometimes □φ → □always φ`

6. **Lines 61-75 - Quick Start Code Examples**:
   - Current: `�p � p` should be `□p → p`
   - Current: `�"p" � "p"` should be `□"p" → "p"`
   - Current: Variable names use `�` instead of `φ`

**Hexdump Evidence**:
```
00000290: Modal operators corrupted at offset 0x2b0-0x2d0
000003c0: Axiom formulas corrupted at offset 0x3c0-0x4d0
00000500: Perpetuity principles corrupted at offset 0x500-0x690
00000820: Code examples corrupted at offset 0x820-0x9f0
```

**Root Cause**: The file was likely edited with an editor that doesn't support or preserve UTF-8 mathematical operators, or symbols were copied from a source that corrupted them during transfer.

### 2. Project Structure File Tree Issues

**Location**: README.md lines 94-107

**Current State**:
```
ProofChecker/
   ProofChecker/          # Main source
      Syntax/            # Formula types, DSL
      ProofSystem/       # Axioms, rules, derivability
      Semantics/         # Task frame semantics
      Metalogic/         # Soundness, completeness
      Theorems/          # Key theorems (perpetuity)
      Automation/        # Tactics, proof search
   Examples/              # Usage examples
   Tests/                 # Test suite
   docs/                  # User documentation
   src/docs/              # Developer standards
```

**Problem**: Missing box-drawing characters for proper file tree visualization. Current indentation-only approach is ambiguous and lacks visual structure.

**Should Use Unicode Box-Drawing**:
- Vertical lines: `│`
- Intersections: `├─`
- Corners: `└─`
- Horizontal lines: `─`

**Recommended Format** (following CLAUDE.md style in line 1-150):
```
ProofChecker/
├── ProofChecker/           # Main source directory
│   ├── Syntax/            # Formula types, parsing, DSL
│   ├── ProofSystem/       # Axioms and inference rules
│   ├── Semantics/         # Task frame semantics
│   ├── Metalogic/         # Soundness and completeness
│   ├── Theorems/          # Key theorems (perpetuity)
│   └── Automation/        # Tactics, proof search
├── ProofCheckerTest/      # Test suite
├── Archive/               # Pedagogical examples
├── docs/                  # User documentation
└── lakefile.toml          # Build configuration
```

### 3. Logos Glossary Reference Analysis

**Location**: `/home/benjamin/Documents/Philosophy/Projects/Logos/docs/glossary/logical-operators.md`

**Structure Patterns Identified**:

The Logos glossary demonstrates excellent organization for formal operator documentation:

**Format Elements**:
1. **Header Navigation** (lines 1-5): Breadcrumb links to parent directories
2. **Purpose Statement** (line 5): One-paragraph description of glossary scope
3. **Category Organization** (lines 9-206): Hierarchical grouping by operator type
4. **Entry Structure** (each operator):
   - Symbol with pronunciation if needed (e.g., `□ (box)`, `◇ (diamond)`)
   - Natural language description
   - Formal definition when applicable
   - Interdefinability relationships
   - Examples with concrete usage
   - Cross-references to related operators
   - Academic references when relevant

**Category Hierarchy Used**:
- Boolean/Propositional Operators (¬, ∧, ∨, →, ↔, ⊥, ⊤)
- Modal Operators (□, ◇, Ca)
- Temporal Operators (P, F, G, H)
- Counterfactual Operators (□→, ◇→)
- Constitutive/Explanatory Operators (≤, ⊑, ≡, ≼)
- Causal Operators (○→)
- Epistemic Operators (⟹, B, Pr, Mi, Mu)
- Normative/Deontic Operators (O, P, ≺)

**Documentation Standards** (lines 11-215):
- Every operator has Unicode symbol prominently displayed
- Natural language explanations before formal notation
- "See also" links to related operators
- Examples use consistent formatting with formal notation
- References to architecture documentation where applicable
- Last updated timestamp (line 216)

**Key Insights for ProofChecker**:
1. Glossary should be separate file in `docs/glossary/` directory
2. Operators grouped by logic type (modal, temporal, propositional)
3. Each entry includes symbol, meaning, and formal definition
4. Cross-references essential for understanding operator relationships
5. Examples help bridge formal and informal understanding

### 4. Documentation Standards Analysis

**Location**: `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/.claude/docs/reference/standards/documentation-standards.md`

**Relevant Standards for Unicode** (lines 340-354):

**Allowed Unicode Characters**:
- Box-drawing (U+2500-U+257F): ├ │ └ ─ ┌ ┐ ┤ ┬ ┴ ┼
- Arrows (U+2190-U+21FF): ← → ↔ ↑ ↓
- Mathematical operators (U+2200-U+22FF): ≥ ≤ × ≠ ± ∞
- Bullets and punctuation (U+2000-U+206F): • – — … ‹ ›
- Geometric shapes (U+25A0-U+25FF): ▼ ▲ ■ □ ◆
- Miscellaneous symbols (U+2600-U+26FF): ⚠ ✓ ☐ ☑ ★

**Prohibited Characters**:
- Emoji characters (U+1F300-U+1F9FF): 😀 🎉 ✨ 📝 🚀 ❌

**Rationale** (line 353): "Unicode symbols are standard technical notation used in diagrams, lists, and documentation. Emojis cause UTF-8 encoding issues across different terminals and editors."

**Box-Drawing Example** (lines 355-359):
- Corners: ┌ ┐ └ ┘
- Lines: ─ │
- Intersections: ├ ┤ ┬ ┴ ┼
- Example reference: See .claude/README.md for workflow diagrams

**Location**: `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/development/LEAN_STYLE_GUIDE.md`

**Variable Naming Conventions** (lines 6-24):
- Formulas: Use `φ`, `ψ`, `χ` (phi, psi, chi)
- Contexts: Use `Γ`, `Δ` (Gamma, Delta)
- Times: Use `τ`, `σ` (tau, sigma)
- World histories: Use `τ`, `σ` (tau, sigma)

**Implication**: ProofChecker already has documentation standards for Unicode symbols in LEAN code. README.md should follow same conventions for consistency.

### 5. Unicode Best Practices for TM Logic

Based on research and Logos patterns, here are the standard Unicode symbols ProofChecker should use:

**Modal Logic Operators**:
- Necessity: `□` (U+25A1, WHITE SQUARE) - standard in modal logic
- Possibility: `◇` (U+25C7, WHITE DIAMOND) - dual of necessity
- Negation: `¬` (U+00AC, NOT SIGN)
- Implication: `→` (U+2192, RIGHTWARDS ARROW)
- Biconditional: `↔` (U+2194, LEFT RIGHT ARROW)
- Conjunction: `∧` (U+2227, LOGICAL AND)
- Disjunction: `∨` (U+2228, LOGICAL OR)

**Temporal Operators**:
- ProofChecker uses English words: `Past`, `Future`, `always`, `sometimes`
- Alternative symbols if needed:
  - Always (G): `G` or `□` with subscript
  - Sometimes (F): `F` or `◇` with subscript
  - Since: `S`
  - Until: `U`

**Meta-logical Symbols**:
- Provability: `⊢` (U+22A2, RIGHT TACK)
- Semantic consequence: `⊨` (U+22A8, TRUE)
- For all: `∀` (U+2200, FOR ALL)
- Exists: `∃` (U+2203, THERE EXISTS)
- Element of: `∈` (U+2208, ELEMENT OF)
- Not element of: `∉` (U+2209, NOT AN ELEMENT OF)
- Subset: `⊆` (U+2286, SUBSET OF OR EQUAL TO)
- Proper subset: `⊂` (U+2282, SUBSET OF)
- Empty set: `∅` (U+2205, EMPTY SET)

**Propositional Variables**:
- Greek lowercase: `φ`, `ψ`, `χ` (phi, psi, chi)
- Latin lowercase: `p`, `q`, `r`

**Context Variables**:
- Greek uppercase: `Γ`, `Δ` (Gamma, Delta)

**File Tree Characters**:
- Vertical line: `│` (U+2502, BOX DRAWINGS LIGHT VERTICAL)
- Horizontal line: `─` (U+2500, BOX DRAWINGS LIGHT HORIZONTAL)
- Down and right: `┌` (U+250C, BOX DRAWINGS LIGHT DOWN AND RIGHT)
- Down and left: `┐` (U+2510, BOX DRAWINGS LIGHT DOWN AND LEFT)
- Up and right: `└` (U+2514, BOX DRAWINGS LIGHT UP AND RIGHT)
- Up and left: `┘` (U+2518, BOX DRAWINGS LIGHT UP AND LEFT)
- Vertical and right: `├` (U+251C, BOX DRAWINGS LIGHT VERTICAL AND RIGHT)
- Vertical and left: `┤` (U+2524, BOX DRAWINGS LIGHT VERTICAL AND LEFT)
- Down and horizontal: `┬` (U+252C, BOX DRAWINGS LIGHT DOWN AND HORIZONTAL)
- Up and horizontal: `┴` (U+2534, BOX DRAWINGS LIGHT UP AND HORIZONTAL)
- Cross: `┼` (U+253C, BOX DRAWINGS LIGHT VERTICAL AND HORIZONTAL)

### 6. Existing Documentation Structure

**Current Documentation Files**:
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/ARCHITECTURE.md`
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/TUTORIAL.md`
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/EXAMPLES.md`
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/CONTRIBUTING.md`
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/INTEGRATION.md`
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/VERSIONING.md`
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/development/` (5 files)

**Gap Identified**: No `docs/glossary/` directory exists. This should be created following Logos pattern.

**Recommended Location**: `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/glossary/logical-operators.md`

**Integration Point**: README.md should link to glossary in documentation section (around line 78-84).

## Recommendations

### Recommendation 1: Fix README.md Unicode Corruption (Critical Priority)

**Action**: Replace all `�` replacement characters with correct Unicode symbols in README.md.

**Affected Sections**:
1. Line 18 - Modal operators definition
2. Lines 23-25 - Axiom schemas
3. Lines 28-33 - Perpetuity principles
4. Lines 61-75 - Code examples

**Implementation**:
- Use UTF-8 editor (VS Code, vim with UTF-8 encoding)
- Replace systematically using search/replace:
  - `�` in modal context → `□` or `◇` as appropriate
  - `�` in implication context → `→`
  - `�` as variable → `φ`
- Verify encoding with `file -b --mime-encoding README.md` (should return "utf-8")
- Test display in multiple terminals/browsers

**Testing**:
```bash
# Verify no replacement characters remain
grep -n "�" README.md
# Should return no results

# Verify correct symbols present
grep -n "□\|◇\|→\|φ" README.md
# Should match lines 18, 23-25, 28-33, 61-75
```

### Recommendation 2: Enhance Project Structure with Box-Drawing Characters

**Action**: Replace indentation-only file tree with proper Unicode box-drawing in README.md lines 94-107.

**Format Pattern** (from CLAUDE.md lines 41-77):
```markdown
## Project Structure

```
ProofChecker/
├── ProofChecker.lean           # Library root (re-exports all public modules)
├── ProofChecker/               # Main source directory
│   ├── Syntax/                 # Formula types, parsing, DSL
│   │   ├── Formula.lean        # Core formula inductive type
│   │   ├── Context.lean        # Proof context (premise lists)
│   │   └── DSL.lean            # Domain-specific syntax
│   ├── ProofSystem/            # Axioms and inference rules
│   │   ├── Axioms.lean         # TM axiom schemata
│   │   ├── Rules.lean          # Inference rules (MP, MK, TK, TD)
│   │   └── Derivation.lean     # Derivability relation
│   ├── Semantics/              # Task frame semantics
│   │   ├── TaskFrame.lean      # Task frame structure
│   │   ├── WorldHistory.lean   # World history definition
│   │   ├── TaskModel.lean      # Model with valuation
│   │   ├── Truth.lean          # Truth evaluation
│   │   └── Validity.lean       # Validity and consequence
│   ├── Metalogic/              # Soundness and completeness
│   │   ├── Soundness.lean      # Soundness theorem
│   │   ├── Completeness.lean   # Completeness theorem
│   │   └── Decidability.lean   # Decision procedures
│   ├── Theorems/               # Key theorems
│   │   └── Perpetuity.lean     # P1-P6 perpetuity principles
│   └── Automation/             # Proof automation
│       ├── Tactics.lean        # Custom tactics
│       └── ProofSearch.lean    # Automated proof search
├── ProofCheckerTest/           # Test suite
│   ├── ProofCheckerTest.lean   # Test library root
│   ├── Syntax/                 # Tests for formula construction
│   ├── ProofSystem/            # Tests for axioms and rules
│   ├── Semantics/              # Tests for semantics
│   ├── Integration/            # Cross-module tests
│   └── Metalogic/              # Soundness/completeness tests
├── Archive/                    # Pedagogical examples
│   ├── Archive.lean            # Archive library root
│   ├── ModalProofs.lean        # S5 modal logic examples
│   ├── TemporalProofs.lean     # Temporal reasoning examples
│   └── BimodalProofs.lean      # Combined examples
├── Counterexamples/            # Invalidity demonstrations
│   └── Counterexamples.lean    # Counterexamples library root
├── docs/                       # User documentation
│   ├── ARCHITECTURE.md         # System design and TM spec
│   ├── TUTORIAL.md             # Getting started guide
│   ├── EXAMPLES.md             # Usage examples
│   ├── CONTRIBUTING.md         # Contribution guidelines
│   ├── glossary/               # Formal symbols glossary [NEW]
│   │   └── logical-operators.md # Modal, temporal, meta-logical symbols
│   └── development/            # Developer standards
│       ├── LEAN_STYLE_GUIDE.md     # Coding conventions
│       ├── MODULE_ORGANIZATION.md  # Directory structure
│       ├── TESTING_STANDARDS.md    # Test requirements
│       ├── TACTIC_DEVELOPMENT.md   # Custom tactic patterns
│       └── QUALITY_METRICS.md      # Quality targets
├── lakefile.toml               # LEAN 4 build configuration
├── lean-toolchain              # LEAN version pinning
├── .gitignore                  # Git exclusions
└── .github/workflows/ci.yml    # CI/CD pipeline
```
```

**Benefits**:
- Clear visual hierarchy
- Easier to scan and understand structure
- Consistent with CLAUDE.md format
- Professional appearance
- Matches industry standard documentation practices

### Recommendation 3: Create Formal Symbols Glossary

**Action**: Create `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/glossary/logical-operators.md` following Logos pattern.

**Structure** (based on Logos glossary lines 1-216):

```markdown
# Logical Operators

_[Return to Documentation](../README.md) | [ProofChecker Root](../../README.md) | [CLAUDE.md](../../CLAUDE.md)_

Comprehensive catalog of formal operators used in the ProofChecker bimodal logic TM (Tense and Modality) implementation. These operators provide the expressive power for combining S5 modal logic with linear temporal logic in task semantics.

## Terms

### Propositional Operators

#### ¬ (negation)
Logical "not" operator. Reverses truth value.

**Formal Definition**: `neg φ := φ → ⊥`

**LEAN Code**: `def neg (φ : Formula) : Formula := φ.imp Formula.bot`

#### ∧ (conjunction)
Logical "and" operator. True when both operands are true.

**Formal Definition**: `φ ∧ ψ := ¬(φ → ¬ψ)`

**LEAN Code**: `def and (φ ψ : Formula) : Formula := neg (φ.imp (neg ψ))`

#### ∨ (disjunction)
Logical "or" operator. True when at least one operand is true.

**Formal Definition**: `φ ∨ ψ := ¬φ → ψ`

**LEAN Code**: `def or (φ ψ : Formula) : Formula := (neg φ).imp ψ`

#### → (implication)
Logical "if...then" operator. False only when antecedent is true and consequent is false.

**Primitive operator** in ProofChecker's formula type.

**LEAN Code**: `Formula.imp φ ψ`

#### ↔ (biconditional)
Logical "if and only if" operator. True when both operands have the same truth value.

**Formal Definition**: `φ ↔ ψ := (φ → ψ) ∧ (ψ → φ)`

#### ⊥ (bottom/falsum)
Logical constant representing falsity.

**Primitive operator** in ProofChecker's formula type.

**LEAN Code**: `Formula.bot`

#### ⊤ (top/verum)
Logical constant representing truth.

**Formal Definition**: `⊤ := ⊥ → ⊥`

### Modal Operators (S5 Logic)

#### □ (box/necessity)
Necessity operator: "it is necessary that" or "it is necessarily the case that".

**Primitive operator** in ProofChecker's formula type.

**LEAN Code**: `Formula.box φ`

**Semantics**: `M, τ, t ⊨ □φ` iff for all world histories `σ`, `M, σ, t ⊨ φ`

**Axioms**:
- MT (Modal T): `□φ → φ` (what is necessary is actual)
- M4 (Modal 4): `□φ → □□φ` (necessity is necessary)
- MB (Modal B): `φ → □◇φ` (actuality implies possible necessity)

**See also**: [Possibility (◇)](#◇-diamondpossibility), [Perpetuity Principles](#perpetuity-principles)

#### ◇ (diamond/possibility)
Possibility operator: "it is possible that". Dual of necessity.

**Formal Definition**: `◇φ := ¬□¬φ`

**LEAN Code**: `def diamond (φ : Formula) : Formula := neg (box (neg φ))`

**Semantics**: `M, τ, t ⊨ ◇φ` iff there exists a world history `σ` such that `M, σ, t ⊨ φ`

**See also**: [Necessity (□)](#□-boxnecessity)

### Temporal Operators (Linear Temporal Logic)

#### Past (universal past)
Universal past operator: "it has always been the case that" or "at all past times".

**Primitive operator** in ProofChecker's formula type.

**LEAN Code**: `Formula.past φ`

**Semantics**: `M, τ, t ⊨ Past φ` iff for all times `s < t`, `M, τ, s ⊨ φ`

#### Future (universal future)
Universal future operator: "it will always be the case that" or "at all future times".

**Primitive operator** in ProofChecker's formula type.

**LEAN Code**: `Formula.future φ`

**Semantics**: `M, τ, t ⊨ Future φ` iff for all times `s > t`, `M, τ, s ⊨ φ`

**Axioms**:
- T4: `Future φ → Future Future φ` (future persists into future)
- TA: `φ → Future past φ` (present becomes past in future)
- TL: `always φ → Future Past φ` (perpetual truth persists)

#### past (existential past)
Existential past operator: "at some past time" or "it was once the case that".

**Formal Definition**: `past φ := ¬Past ¬φ`

#### future (existential future)
Existential future operator: "at some future time" or "it will be the case that".

**Formal Definition**: `future φ := ¬Future ¬φ`

### Combined Modal-Temporal Operators

#### always (perpetual truth)
Always operator: "at all times" (combines universal past and future).

**Formal Definition**: `always φ := Past φ ∧ φ ∧ Future φ`

**Semantics**: True at all times in the model.

**See also**: [Perpetuity Principle P1](#p1-necessity-implies-perpetuity)

#### sometimes (temporal possibility)
Sometimes operator: "at some time" (combines existential past and future).

**Formal Definition**: `sometimes φ := past φ ∨ φ ∨ future φ`

**Semantics**: True at some time in the model.

**See also**: [Perpetuity Principle P2](#p2-temporal-occurrence-implies-possibility)

### Meta-logical Symbols

#### ⊢ (provability)
Provability relation: `Γ ⊢ φ` means "φ is derivable from context Γ".

**LEAN Code**: `Derivable Γ φ` (inductive type)

**See also**: Soundness theorem, Completeness theorem

#### ⊨ (semantic consequence)
Semantic consequence relation: `Γ ⊨ φ` means "φ is a semantic consequence of Γ" (valid in all models satisfying Γ).

**LEAN Code**: `valid Γ φ`

**See also**: Soundness theorem (`⊢` implies `⊨`), Completeness theorem (`⊨` implies `⊢`)

### Perpetuity Principles

These derived theorems connect modal and temporal operators in TM logic.

#### P1 (Necessity Implies Perpetuity)
`□φ → always φ`

What is necessary is always the case (at all times).

**LEAN Code**: `theorem perpetuity_1 (φ : Formula) : ⊢ (φ.box.imp (always φ))`

**Location**: `ProofChecker/Theorems/Perpetuity.lean`

#### P2 (Temporal Occurrence Implies Possibility)
`sometimes φ → ◇φ`

What is sometimes the case is possible.

**LEAN Code**: `theorem perpetuity_2 (φ : Formula) : ⊢ ((sometimes φ).imp φ.diamond)`

#### P3 (Necessity of Perpetuity)
`□φ → □always φ`

Necessity implies necessary perpetuity.

**LEAN Code**: `theorem perpetuity_3 (φ : Formula) : ⊢ (φ.box.imp (always φ).box)`

#### P4 (Possibility of Occurrence)
`◇sometimes φ → ◇φ`

Possible temporal occurrence implies possibility.

**LEAN Code**: `theorem perpetuity_4 (φ : Formula) : ⊢ ((sometimes φ).diamond.imp φ.diamond)`

#### P5 (Persistent Possibility)
`◇sometimes φ → always ◇φ`

Possible temporal occurrence implies persistent possibility.

**LEAN Code**: `theorem perpetuity_5 (φ : Formula) : ⊢ ((sometimes φ).diamond.imp (always φ.diamond))`

#### P6 (Occurrent Necessity is Perpetual)
`sometimes □φ → □always φ`

Temporal occurrence of necessity implies necessary perpetuity.

**LEAN Code**: `theorem perpetuity_6 (φ : Formula) : ⊢ ((sometimes φ.box).imp (always φ).box)`

## Variable Conventions

Following ProofChecker LEAN Style Guide conventions:

- **Formulas**: `φ`, `ψ`, `χ` (phi, psi, chi)
- **Contexts**: `Γ`, `Δ` (Gamma, Delta)
- **Models**: `M`, `N`
- **Frames**: `F`
- **World histories**: `τ`, `σ` (tau, sigma)
- **Times**: `t`, `s`

---

**Related Documentation:**
- [ARCHITECTURE.md](../ARCHITECTURE.md) - Complete TM logic specification
- [LEAN Style Guide](../development/LEAN_STYLE_GUIDE.md) - Variable naming conventions
- [Examples](../EXAMPLES.md) - Usage examples for operators
- [Tutorial](../TUTORIAL.md) - Getting started guide

_Last updated: 2025-12-01_
```

**Integration**:
- Add link to glossary in README.md documentation section
- Add link to glossary in CLAUDE.md documentation index
- Reference glossary from ARCHITECTURE.md when defining operators
- Update CONTRIBUTING.md to mention glossary as reference

### Recommendation 4: Update Documentation Standards for File Trees

**Action**: Add file tree formatting standards to `.claude/docs/reference/standards/documentation-standards.md`.

**Insertion Point**: After line 359 (Unicode Box-Drawing section)

**Content to Add**:

```markdown
### File Tree Formatting Standards

**Requirement**: All file trees in README.md and documentation must use Unicode box-drawing characters.

**Standard Characters**:
- Vertical line: `│` (U+2502)
- Horizontal line: `─` (U+2500)
- Branch (├─): Connects to item with siblings below
- Last branch (└─): Connects to final item in directory
- Continuation (│  ): Vertical line through sibling items

**Pattern Template**:
```
ProjectName/
├── directory/              # First item
│   ├── subdirectory/      # Nested item with siblings
│   │   ├── file1.ext      # File with sibling
│   │   └── file2.ext      # Last file in directory
│   └── another-subdir/    # Last subdir
├── another-directory/     # Middle item
│   └── file.ext           # Single item
└── last-directory/        # Last item (use └─)
    └── file.ext
```

**Anti-Patterns**:
```
# WRONG: Indentation only (ambiguous hierarchy)
ProjectName/
  directory/
    subdirectory/
      file1.ext
      file2.ext

# WRONG: Inconsistent characters
ProjectName/
|- directory/              # Mix of ASCII and Unicode
|  |- file.ext
```

**Best Practices**:
1. Align comments at consistent column (e.g., column 40)
2. Use 4 spaces or equivalent for each nesting level
3. Include only representative files (don't list every file)
4. Group related items together
5. Add descriptive comments for non-obvious directories

**Tools**:
- Many editors have tree generator plugins (e.g., VS Code "File Tree Generator")
- Command-line: `tree -F --charset unicode` (requires tree utility)
- Manual construction using template above

**Validation**: Visual inspection - tree should be unambiguous about hierarchy.

See CLAUDE.md lines 41-77 for reference implementation.
```

**Benefits**:
- Codifies existing best practices from CLAUDE.md
- Provides template for consistent file trees across documentation
- Prevents regression to indentation-only format
- Supports onboarding by documenting tool usage

### Recommendation 5: Add Symbol Glossary to CLAUDE.md Documentation Index

**Action**: Update CLAUDE.md section 4 (Documentation Index) to include glossary reference.

**Location**: `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/CLAUDE.md` lines 80-93

**Current Content**:
```markdown
### User Documentation (docs/)
- [Architecture Guide](docs/ARCHITECTURE.md) - System design and TM logic specification
- [Tutorial](docs/TUTORIAL.md) - Getting started with ProofChecker
- [Examples](docs/EXAMPLES.md) - Modal, temporal, bimodal examples
- [Contributing](docs/CONTRIBUTING.md) - How to contribute
- [Integration](docs/INTEGRATION.md) - Model-Checker integration
- [Versioning](docs/VERSIONING.md) - Semantic versioning policy
```

**Add After Line 85**:
```markdown
- [Logical Operators Glossary](docs/glossary/logical-operators.md) - Formal symbols reference
```

**Final Order**:
1. Architecture Guide (system overview)
2. **Glossary (symbol reference)** ← NEW
3. Tutorial (getting started)
4. Examples (usage patterns)
5. Contributing (development process)
6. Integration (external tools)
7. Versioning (release policy)

**Rationale**: Glossary should come early (after Architecture) as a reference for understanding the rest of the documentation.

## Implementation Priority

**Phase 1 - Critical (Immediate)**:
1. Fix README.md Unicode corruption (Recommendation 1)
2. Enhance README.md file tree with box-drawing (Recommendation 2)

**Phase 2 - High Priority (Short-term)**:
3. Create formal symbols glossary (Recommendation 3)
4. Update CLAUDE.md to link glossary (Recommendation 5)

**Phase 3 - Documentation Standards (Medium-term)**:
5. Add file tree formatting to documentation standards (Recommendation 4)

## References

### Files Analyzed
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/README.md` - Lines 1-158 (entire file)
- `/home/benjamin/Documents/Philosophy/Projects/Logos/docs/glossary/logical-operators.md` - Lines 1-216 (entire file)
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/.claude/docs/reference/standards/documentation-standards.md` - Lines 1-465 (entire file, focus on 340-359)
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/docs/development/LEAN_STYLE_GUIDE.md` - Lines 1-382 (entire file, focus on 6-24)
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/CLAUDE.md` - Lines 41-150 (file tree reference)
- `/home/benjamin/Documents/Philosophy/Projects/ProofChecker/.claude/docs/reference/standards/code-standards.md` - Lines 1-466 (standards context)

### Hexdump Analysis
- Corruption offsets: 0x2b0-0x2d0, 0x3c0-0x4d0, 0x500-0x690, 0x820-0x9f0
- Byte pattern: `ef bf bd` (UTF-8 encoding of U+FFFD replacement character)
- Total corrupted bytes: ~135 bytes (45 replacement characters × 3 bytes each)

### Unicode Standards References
- Box-drawing characters: U+2500-U+257F
- Mathematical operators: U+2200-U+22FF (includes ∀, ∃, ∈, ⊆, ⊢, ⊨)
- Geometric shapes: U+25A0-U+25FF (includes □, ◇)
- Arrows: U+2190-U+21FF (includes →, ↔)

### External Best Practices
- CommonMark Specification: https://commonmark.org/
- Unicode Standard: https://unicode.org/charts/
- Logos Project Glossary Pattern: Proven in production documentation
- Mathlib4 Naming Conventions: Adapted for ProofChecker LEAN code

---

## Implementation Status
- **Status**: Planning In Progress
- **Plan**: [../plans/001-unicode-symbol-standardization-plan.md](../plans/001-unicode-symbol-standardization-plan.md)
- **Implementation**: [Will be updated by orchestrator]
- **Date**: 2025-12-01

---

**Report Status**: Complete
**Next Action**: Create implementation plan based on recommendations
