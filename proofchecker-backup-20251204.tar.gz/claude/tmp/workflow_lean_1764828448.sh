export CLAUDE_PROJECT_DIR="/home/benjamin/Documents/Philosophy/Projects/ProofChecker"
export WORKFLOW_ID="lean_1764828448"
export STATE_FILE="/home/benjamin/Documents/Philosophy/Projects/ProofChecker/.claude/tmp/workflow_lean_1764828448.sh"
