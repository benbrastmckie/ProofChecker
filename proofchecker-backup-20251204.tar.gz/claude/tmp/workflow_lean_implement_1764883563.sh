export CLAUDE_PROJECT_DIR="/home/benjamin/Documents/Philosophy/Projects/ProofChecker"
export WORKFLOW_ID="lean_implement_1764883563"
export STATE_FILE="/home/benjamin/Documents/Philosophy/Projects/ProofChecker/.claude/tmp/workflow_lean_implement_1764883563.sh"
